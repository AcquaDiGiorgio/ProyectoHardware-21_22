#ifndef PANTALLA_H
#define PANTALLA_H

	void pantalla_add_to_buffer(volatile char buff[], int size);
	void pantalla_write_buffer(void);
	
#endif //PANTALLA_H
