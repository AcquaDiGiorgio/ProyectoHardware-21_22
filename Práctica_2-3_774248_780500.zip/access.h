#ifndef ACCESS_H
#define ACCESS_H

		#include "constantes_comunes.h"

		void lock(void);
		void unlock(void);

#endif //ACCESS_H
